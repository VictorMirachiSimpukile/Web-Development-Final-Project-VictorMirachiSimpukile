   
   // Import the functions you need from the SDKs you need
   import { initializeApp } from "https://www.gstatic.com/firebasejs/9.17.1/firebase-app.js";
   import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.17.1/firebase-analytics.js";
   import {
    getAuth,
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword
  } from "https://www.gstatic.com/firebasejs/9.17.1/firebase-auth.js";
  
  const firebaseConfig = {
    apiKey: "AIzaSyAk9I-3mq185Z6MRq_LUrnniwsYk3V1Nqs",
    authDomain: "bootcampweb-465ec.firebaseapp.com",
    projectId: "bootcampweb-465ec",
    storageBucket: "bootcampweb-465ec.appspot.com",
    messagingSenderId: "322369885312",
    appId: "1:322369885312:web:9c215f7eb861cb6a8f0265",
    measurementId: "G-45306ZTH0L"
  };

    // Initialize Firebase
    const app = initializeApp(firebaseConfig);
    const auth = getAuth();

    //login filed .
     const emailInput = document.getElementById("email");
     const passwordInput = document.getElementById("password");
     const logIn = document.getElementById("log_in");
     const submitButton = document.getElementById("submit_btn");
     const  returnBtn = document.getElementById("hide") 

     //signup field
     const signupEmailIn = document.getElementById("newemail");
     const confirmEmailIn = document.getElementById("confirmemail");
     const signupPasswordIn = document.getElementById("newpassword");
     const confirmPasswordIn = document.getElementById("confirmpassword");
     const signUP = document.getElementById("sign_up");
     const createAccountButton = document.getElementById("creat_account_btn");
     const backButton = document.getElementById("back_btn");
     var email,
     password,
     signupEmail,
     signupPassword,
     confirmEmail,
     confirmPassword;

createAccountButton.addEventListener("click", function (){
  var isVarified = true;

  signupEmail = signupEmailIn.value;
  confirmEmail = confirmEmailIn.value;
  if (signupEmail != confirmEmail) {
    window.alert("emails did not match");
    isVarified = false;
  }

  signupPassword = signupPasswordIn.value;
  confirmPassword = confirmPasswordIn.value;
  if (signupPassword != confirmPassword) {
    window.alert("your passwords did not match")
    isVarified = false;
  };

  if (
    signupEmail == null ||
    confirmEmail == null ||
    signupPassword == null ||
    confirmPassword == null 
    ) {
    window.alert("please fill in all the fields");
    isVarified = false;
  };

      if (isVarified) {
        createUserWithEmailAndPassword(auth,signupEmail,signupPassword)
        .then((userCredential) => {
          const user = userCredential.user;
          window.alert("account created successfully");
          window.location = "./createTask.html"
        });
      };
     });
     returnBtn.addEventListener("click",function(){
      document.getElementById("log_in").style.display="none",
      document.getElementById("sign_up").style.display="block"
     });
     backButton.addEventListener("click",function(){
      document.getElementById("log_in").style.display="block",
      document.getElementById("sign_up").style.display="none"
     });
     submitButton.addEventListener("click", function () {
      email = emailInput.value;
      // console.log(email);
      password = passwordInput.value;
      // console.log(password);
    
      signInWithEmailAndPassword(auth, email, password)
        .then((userCredential) => {
          // Signed in
          const user = userCredential.user;
    
          window.alert("Success! Welcome back!");
          window.location = "./createTask.html";
    
          // ...
        })
        .catch((error) => {
          // const errorCode = error.code;
          // const errorMessage = error.message;
          window.alert("Error occurred. Try again.");
        });
    });


  
     
